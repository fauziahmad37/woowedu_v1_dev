#!/bin/bash
echo `date`: Recipe ID: -318;
sh /root/recipe_-318.sh > /root/recipe_-318.log 2>&1;
echo `date`: RET: $?;
rm -f /root/recipe_-318.sh;
rm -f /root/exec_recipe.sh