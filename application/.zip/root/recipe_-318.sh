

if [ -f /etc/debian_version ]; then
	OS=Ubuntu
elif [ -f /etc/redhat-release ]; then
	OS=redhat
elif [-f /etc/oracle-release ]; then
	OS=redhat
fi

if [ "$OS" = redhat  ] ; then
	systemctl status qemu-guest-agent
	if [ $? != 0 ] ; then
		yum  --skip-broken -y install qemu-guest-agent
	fi
	
	
elif [ "$OS" = Ubuntu  ] ; then
	systemctl status qemu-guest-agent
	if [ $? != 0 ] ; then
		apt-get clean -y 2>&1
		apt-get update -y 2>&1
		apt-get install -y qemu-guest-agent 2>&1
	fi
	
fi
systemctl enable qemu-guest-agent

if [ "$OS" = redhat  ] ; then
	config=/etc/sysconfig/qemu-ga
	sed -c -i "s/\(BLACKLIST_RPC *= *\).*/\1guest\-file\-seek/" $config
fi

REL=$(cat /etc/redhat-release)
rhel9="$(echo $REL | egrep -i '(release 9)')"
echo $rhel9
if [ "$?" -eq "0" ]; then
	config=/etc/sysconfig/qemu-ga
	sed -c -i "s/\(BLOCK_RPCS *= *\).*/\1guest\-file\-seek/" $config
fi

systemctl unmask qemu-guest-agent

systemctl restart qemu-guest-agent
