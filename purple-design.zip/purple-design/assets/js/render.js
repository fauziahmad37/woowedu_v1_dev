
(async () => {

    await renderHeader();

})()

function renderHeader() {
    return fetch('header.mustache')
            .then(resp => resp.text())
            .then(tpl => {

                const tmpl = Mustache.render(tpl, {});
                document.getElementsByTagName('header')[0].innerHTML = tmpl;
            });  

}


function renderSidebar() {
    return fetch('sidebar.mustache')
            .then(resp => resp.text())
            .then(tpl => {

                const tmpl = Mustache.render(tpl, {});
                document.getElementsByTagName('aside')[0].innerHTML = tmpl;
            });  

}