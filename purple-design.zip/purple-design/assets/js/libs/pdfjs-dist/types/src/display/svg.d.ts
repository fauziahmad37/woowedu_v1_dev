/** @type {any} */
export let SVGGraphics: any;
